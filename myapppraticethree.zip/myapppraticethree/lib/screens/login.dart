import 'package:flutter/material.dart';

class Login extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold (
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.account_tree_rounded, size: 92,
                color: Colors.teal),
            SizedBox(height: 25),
            Text('Family Search', style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.black,
            ),),
            SizedBox(height: 25),
            TextField(
              keyboardType: TextInputType.emailAddress,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                label: Text("E-mail"),
              ),
            ),
            SizedBox(height: 25),
            TextField(
              keyboardType: TextInputType.text,
              obscureText: true,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                label: Text("Password"),
              ),
            ),
            SizedBox(height: 25),
            TextButton(
              onPressed: () => Navigator.pushReplacementNamed(context, '/lista'),
              child: Text(
                  'ENTER'
              ),
              style: TextButton.styleFrom(
                primary: Colors.black,
                backgroundColor: Colors.teal
              )
            ),
          ],
        )
    );
  }
}